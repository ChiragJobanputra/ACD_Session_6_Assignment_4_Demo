var Employee1 = {
  Name: "Justin Bieber",
  Age: 32,
  Salary: 52000,
  Address: {
    City: "Los Angeles",
    State: "California",
    Pincode: 5654689
  }
};
var Employee2 = {
  Name: "Zayn Malik",
  Age: 42,
  Salary: 12000,
  Address: {
    City: "Bradford",
    State: "West Yorkshire",
    Pincode: 1213423
  }
};
var Employee3 = {
  Name: "Kendall Jenner",
  Age: 26,
  Salary: 532600,
  Address: {
    City: "Los Angeles",
    State: "California",
    Pincode: 5654689
  }
};
var Employee4 = {
  Name: "Rob Kardashian",
  Age: 36,
  Salary: 67500,
  Address: {
    City: "Paris",
    State: "France",
    Pincode: 4545454
  }
};
var Employee5 = {
  Name: "JTyra Banks",
  Age: 33,
  Salary: 20000,
  Address: {
    City: "Sydney",
    State: "New South Wales",
    Pincode: 8000008
  }
};

var Employee = new Array();
Employee[0] = Employee1;
Employee[1] = Employee2;
Employee[2] = Employee3;
Employee[3] = Employee4;
Employee[4] = Employee5;

for (var prop in Employee) {
  console.log(Employee[prop]);
}
